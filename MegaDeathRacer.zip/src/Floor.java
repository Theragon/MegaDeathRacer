/**
 * Created with IntelliJ IDEA.
 * User: logan
 * Date: 11/22/13
 * Time: 3:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class Floor
{
	public float x, z;

	public Floor(float x, float z)
	{
		this.x = x;
		this.z = z;
	}
}
