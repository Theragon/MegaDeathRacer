/**
 * Created with IntelliJ IDEA.
 * User: logan
 * Date: 11/22/13
 * Time: 2:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class Trail
{
	public float x;
	public float y;
	public float z;
	public float scale;
	public int direction;
	public float start;
	public float end;
	public float startx;
	public float startz;
	public float endx;
	public float endz;

	public Trail(float x, float y, float z, int direction)
	{
		this.x = x;
		this.y = y;
		this.z = z;
		this.direction = direction;
	}
}
